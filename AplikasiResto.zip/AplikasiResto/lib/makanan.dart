class Makanan {
  String nama;
  String deskripsi;
  String gambarUtama;
  String detail;
  String waktuBuka;
  String harga;
  String kalori;
  List<String> gambarLain;
  List<Map<String, String>> bahan;

  Makanan({
    required this.nama,
    required this.deskripsi,
    required this.gambarUtama,
    required this.detail,
    required this.waktuBuka,
    required this.harga,
    required this.kalori,
    required this.gambarLain,
    required this.bahan,
  });

  static List<Makanan> dumpyData = [
    Makanan(
        nama: 'Lunpia',
        deskripsi: 'Rebung',
        gambarUtama: 'assets/lunpia.jpeg',
        detail:
            'Lunpia adalah makanan khas Semarang, Indonesia, yang berupa lumpia atau pangsit goreng. Ciri khas lunpia adalah kulitnya yang tipis dan renyah, diisi dengan berbagai bahan, seperti sayuran, daging, atau udang.',
        waktuBuka: '07.00-10.00',
        harga: 'Rp 50.000',
        gambarLain: [
          'assets/lunpia1.jpg',
          'assets/lunpia2.jpeg',
        ],
        bahan: [],
        kalori: '372 kkal'),
    Makanan(
        nama: 'Serabi',
        deskripsi: 'Makanan berkuah',
        gambarUtama: 'assets/serabi.jpeg',
        detail:
            'Serabi adalah makanan tradisional Indonesia, terutama populer di daerah Jawa. Bentuknya mirip pancake kecil yang terbuat dari adonan tepung beras dan santan, yang biasanya dimasak di atas wajan datar. Serabi memiliki tekstur lembut dan kenyal, dengan aroma khas santan.',
        waktuBuka: '09.00-12.00',
        harga: 'Rp 25.000',
        gambarLain: [
          'assets/serabi1.jpeg',
          'assets/serabi2.jpg',
        ],
        bahan: [],
        kalori: '400 kkal'),
    Makanan(
        nama: 'Lontong Sayur',
        deskripsi: 'Lontong yang dibalut dengan sayuran ',
        gambarUtama: 'assets/lontong.jpeg',
        detail:
            'Lontong sayur adalah hidangan khas Indonesia yang terdiri dari lontong (nasi yang dimasak dalam daun pisang) yang disajikan dengan kuah sayur kental. Kuah sayur ini umumnya terbuat dari santan dan bumbu rempah, serta diisi dengan berbagai sayuran seperti labu siam, kacang panjang, dan telur rebus.',
        waktuBuka: '08.00-16.00',
        harga: 'Rp 15.000',
        gambarLain: [
          'assets/lontong1.jpg',
          'assets/lontong2.jpeg',
        ],
        bahan: [],
        kalori: '426 kkal'),
  ];
}
